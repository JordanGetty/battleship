#include "Header.h"

void print_welcome_screen(void)
{
	
	printf("********Welcome to Battleship!********\n");
	printf("Rules of the Game:\n");
	printf("Player 1 and Player 2 take turns at destroying each others battleships.\n");
	printf("To destroy someones battleship, you must sink every cell that that battleship is in.\n");
	printf("At the start of your turn, pick a row and a column to shoot at.\n");
	printf("It will either be a hit or miss.\n");
	printf("Continue until all ships are sunk.\n");
	
	printf("Hit enter to start the game!\n");
	getch();
	

}


void initialize_game_board(char board[][10], int num_rows, int num_cols)
{
	int row_index = 0, col_index = 0;

	for (; row_index < num_rows; ++row_index)
	{
		for (col_index = 0; col_index < num_cols; ++col_index)
		{
			board[row_index][col_index] = '~';
		}
	}
}


void display_board(char board[][10], int num_rows, int num_cols)
{

	int row_index = 0, col_index = 0, number = 0;

	printf(" 0 1 2 3 4 5 6 7 8 9\n");

	for (; row_index < num_rows; ++row_index)
	{
		for (col_index = 0; col_index < num_cols; ++col_index, ++number)
		{
			printf(" %c", board[row_index][col_index]);
		}
		printf("%d", (number - 1) / 10);
		putchar('\n');
	}
}

int gen_direction(void)
{
	int dir = 0;

	dir = rand() % 2;

	return dir;
}


void gen_start_pt(int dir, int ship_length, int *row_ptr, int *col_ptr)
{
	if (dir == HORIZONTAL) // horizontal
	{
		*row_ptr = rand() % NUM_ROWS;
		*col_ptr = rand() % (NUM_COLS - ship_length + 1);
	}

	else // vertical
	{

		*row_ptr = rand() % (NUM_ROWS - ship_length + 1);
		*col_ptr = rand() % NUM_COLS;
	}
}

void is_valid_ship_placement(char board_check[][NUM_COLS],
	int start_row_pt, int start_col_pt, int ship_length,
			int ship_direction)
{
	int index = 0;

	if (ship_direction == HORIZONTAL)
	{

		while (board_check[start_row_pt][start_col_pt + index] == 1)
		{
			for (index = 0; index < ship_length &&
				board_check[start_row_pt][start_col_pt + index] != 1;
				index++);
			if (board_check[start_row_pt][start_col_pt + index] == 1)
			{
				gen_start_pt(ship_direction, ship_length, &start_row_pt,
					&start_col_pt);
			}
			for (index = 0; index < ship_length &&
				board_check[start_row_pt][start_col_pt + index] != 1;
				++index);
		}
		
	}

	else 
	{
		while (board_check[start_row_pt][start_col_pt + index] == 1)
		{
			for (index = 0; index < ship_length &&
				board_check[start_row_pt + index][start_col_pt] != 1;
				++index);
			if (board_check[start_row_pt + index][start_col_pt] == 1)
			{
				gen_start_pt(ship_direction, ship_length, &start_row_pt,
					&start_col_pt);
			}
			for (index = 0; index < ship_length &&
				board_check[start_row_pt + index][start_col_pt] != 1;
				++index);

		}
	}
}


void place_ship(char board[][NUM_COLS], char board_check[][NUM_COLS], int num_rows, int num_cols,
	char ship_symbol, int ship_length, int ship_direction,
	int start_row_pt, int start_col_pt)
{
	{
		int index = 0;

		if (ship_direction == HORIZONTAL)
		{
			for (index = 0; index < ship_length; ++index)
			{
				board[start_row_pt][start_col_pt + index] = ship_symbol;
				board_check[start_row_pt][start_col_pt + index] = 1;
			}
		}
		else // vertical
		{
			for (index = 0; index < ship_length; ++index)
			{
				board[start_row_pt + index][start_col_pt] = ship_symbol;
				board_check[start_row_pt + index][start_col_pt] = 1;
			}
		}
	}
}


int select_who_starts_first(void)
{

	int starting_player = 0;

	starting_player = rand() % 2;

	return starting_player;

}

