#ifndef PA6
#define PA6

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <conio.h>
//#include <unistd.h>

#define HORIZONTAL 0
#define VERTICAL 1
#define NUM_ROWS 10
#define NUM_COLS 10

void print_welcome_screen(void);

void initialize_game_board(char board[][10], int num_rows, int num_cols);

void display_board(char board[][10], int num_rows, int num_cols);

int gen_direction(void);

void gen_start_pt(int dir, int ship_length, int *row_ptr, int *col_ptr);

void place_ship(char board[][NUM_COLS], int num_rows, int num_cols,
	char ship_symbol, int ship_length, int ship_direction,
	int start_row_pt, int start_col_pt);

int select_who_starts_first(void);











#endif