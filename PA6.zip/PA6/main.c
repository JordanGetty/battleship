#include "Header.h"

int main()
{
	srand((unsigned int)time(NULL));


	char p1_board[10][10] = { { '~', '~' },{ '~' } }, 
		p2_board[10][10] = { { '~', '~' },{ '~' } },
		p1_board_check[10][10] = { { 0, 0 },{ 0 } },
		p2_board_check[10][10] = { { 0, 0 },{ 0 } },
		ship_symbols[5] = { 'c', 'b', 's', 'r', 'd' };
	int ship_lengths[5] = { 5, 4, 3, 3, 2 }, count = 0, dir = 0,
		row_start_pt = 0, col_start_pt = 0;

	initialize_game_board(p1_board, 10, 10);
	initialize_game_board(p2_board, 10, 10);
	//display_board(p1_board, 10, 10);

	for (; count < 5; ++count)
	{
		dir = gen_direction();
		gen_start_pt(dir, ship_lengths[count], 
			&row_start_pt, &col_start_pt);
		/*is_valid_ship_placement(p1_board_check[10][10],
			row_start_pt, col_start_pt, ship_lengths[count], dir);*/
		place_ship(p1_board, p1_board_check, NUM_ROWS, NUM_COLS, ship_symbols[count],
			ship_lengths[count], dir, row_start_pt, col_start_pt);
	}
	display_board(p1_board, NUM_ROWS, NUM_COLS);


	return 0;
}